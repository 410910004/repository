package com.zc.entity;

import java.time.LocalDateTime;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;

import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 
 * </p>
 *
 * @author wz
 * @since 2023-03-31
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value="Sit对象", description="")
public class Sit implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "学生表id")
    @TableField("stuId")
    private Integer stuid;

    @ApiModelProperty(value = "是否专注")
    private String isfocus;

    @ApiModelProperty(value = "坐标")
    private String x;

    @ApiModelProperty(value = "坐标")
    private String y;

    @ApiModelProperty(value = "坐标")
    private String w;

    @ApiModelProperty(value = "坐标")
    private String h;

    @ApiModelProperty(value = "学生坐姿图片")
    private String img;

    @ApiModelProperty(value = "坐姿上传时间")
    @TableField("updateTime")
    private LocalDateTime updatetime;

    @ApiModelProperty(value = "坐姿是否合格")
    private Integer start;


}
