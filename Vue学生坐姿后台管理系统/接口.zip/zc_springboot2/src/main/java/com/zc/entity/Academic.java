package com.zc.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 
 * </p>
 *
 * @author wz
 * @since 2023-04-30
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value="Academic对象", description="")
public class Academic implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    private String name;

    private Integer no;

    private String img;

    @ApiModelProperty(value = "匹配分数")
    private Integer matchs;

    @ApiModelProperty(value = "专注分数")
    private Integer focus;

    @ApiModelProperty(value = "热情分数")
    private Integer enthusiastic;


}
