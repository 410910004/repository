package com.zc.service.impl;

import com.zc.entity.Alarm;
import com.zc.mapper.AlarmMapper;
import com.zc.service.IAlarmService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author wz
 * @since 2023-04-30
 */
@Service
public class AlarmService extends ServiceImpl<AlarmMapper, Alarm> implements IAlarmService {

}
