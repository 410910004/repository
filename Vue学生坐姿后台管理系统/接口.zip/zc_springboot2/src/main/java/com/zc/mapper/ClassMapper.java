package com.zc.mapper;

import com.zc.entity.Class;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author wz
 * @since 2023-03-26
 */
public interface ClassMapper extends BaseMapper<Class> {

}
