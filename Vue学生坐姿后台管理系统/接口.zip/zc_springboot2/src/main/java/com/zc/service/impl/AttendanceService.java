package com.zc.service.impl;

import com.zc.entity.Attendance;
import com.zc.mapper.AttendanceMapper;
import com.zc.service.IAttendanceService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author wz
 * @since 2023-03-26
 */
@Service
public class AttendanceService extends ServiceImpl<AttendanceMapper, Attendance> implements IAttendanceService {

}
