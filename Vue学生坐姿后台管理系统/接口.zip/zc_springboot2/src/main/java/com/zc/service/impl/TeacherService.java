package com.zc.service.impl;

import com.zc.entity.Teacher;
import com.zc.mapper.TeacherMapper;
import com.zc.service.ITeacherService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author wz
 * @since 2023-04-30
 */
@Service
public class TeacherService extends ServiceImpl<TeacherMapper, Teacher> implements ITeacherService {

}
