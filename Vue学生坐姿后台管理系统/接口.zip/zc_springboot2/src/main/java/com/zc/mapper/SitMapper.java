package com.zc.mapper;

import com.zc.entity.Sit;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author wz
 * @since 2023-03-31
 */
public interface SitMapper extends BaseMapper<Sit> {

}
