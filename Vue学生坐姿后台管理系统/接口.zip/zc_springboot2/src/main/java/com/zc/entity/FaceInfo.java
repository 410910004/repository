package com.zc.entity;

import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 
 * </p>
 *
 * @author wz
 * @since 2023-03-26
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value="FaceInfo对象", description="")
public class FaceInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    private String x;

    private String y;

    private String w;

    private String h;

    private String image;


}
