package com.zc.service.impl;

import com.zc.entity.Academic;
import com.zc.mapper.AcademicMapper;
import com.zc.service.IAcademicService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author wz
 * @since 2023-04-30
 */
@Service
public class AcademicService extends ServiceImpl<AcademicMapper, Academic> implements IAcademicService {

}
