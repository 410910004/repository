package com.zc.controller;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zc.common.QueryPageParam;
import com.zc.common.Result;
import com.zc.entity.Attendance;
import com.zc.entity.FaceInfo;
import com.zc.entity.Student;
import com.zc.service.impl.AttendanceService;
import com.zc.service.impl.FaceInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author wz
 * @since 2023-03-26
 */
@RestController
@RequestMapping("/attendance")
public class AttendanceController {
    @Autowired
    private AttendanceService attendanceService;


    //分页查询
    @PostMapping("/listPage")
    public Result listPage(@RequestBody QueryPageParam query) {
        Page<Attendance> page = new Page<>();
        //当前页
        page.setCurrent(query.getPageNum());
        //一页多少条
        page.setSize(query.getPageSize());
        IPage result = attendanceService.page(page);
        return Result.suc(result.getTotal(), result.getRecords());
    }
    //分页+名称查询
    @PostMapping("/listLike")
    public Result listLike(@RequestBody QueryPageParam query){
        LambdaQueryWrapper<Attendance> lambdaQueryWrapper=new LambdaQueryWrapper<>();
        HashMap param= query.getParam();
        String name=(String) param.get("name");


        //当参数为空白或者null时,isNotBlank返回false
        if (StringUtils.isNotBlank(name)){
            lambdaQueryWrapper.like(Attendance::getName,name);
        }

        Page<Attendance> page=new Page<>();
        //当前页
        page.setCurrent(query.getPageNum());
        //一页多少条
        page.setSize(query.getPageSize());
        IPage result = attendanceService.page(page, lambdaQueryWrapper);
        return Result.suc(result.getTotal(),result.getRecords());
    }

    //删除
    @GetMapping("/del")
    public Result delete(@RequestParam String id){
        return attendanceService.removeById(id)?Result.suc():Result.fail();
    }

    //增加
    @PostMapping("/save")
    public Result save(@RequestBody Attendance attendance){   //@RequestBody用于接收前端的参数
        if(attendanceService.save(attendance)){
            List list=attendanceService.lambdaQuery()
                    .eq(Attendance::getNo,attendance.getNo())
                    .list();
            return Result.suc(list.get(0));
        }else {
            return Result.fail();
        }
    }

    //修改
    @PostMapping("/mod")
    public Result mod(@RequestBody Attendance attendance){   //@RequestBody用于接收前端的参数
        if(attendanceService.updateById(attendance)){
            List list = attendanceService.lambdaQuery().eq(Attendance::getId, attendance.getId()).list();
            return Result.suc(list.get(0));
        }else {
            return Result.fail();
        }
    }
}
