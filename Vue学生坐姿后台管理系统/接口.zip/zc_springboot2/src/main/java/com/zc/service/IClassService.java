package com.zc.service;

import com.zc.entity.Class;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author wz
 * @since 2023-03-26
 */
public interface IClassService extends IService<Class> {

}
