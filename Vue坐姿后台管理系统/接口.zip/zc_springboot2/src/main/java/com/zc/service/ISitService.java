package com.zc.service;

import com.zc.entity.Sit;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author wz
 * @since 2023-03-31
 */
public interface ISitService extends IService<Sit> {

}
