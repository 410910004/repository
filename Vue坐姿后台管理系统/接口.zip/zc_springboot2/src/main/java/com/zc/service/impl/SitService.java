package com.zc.service.impl;

import com.zc.entity.Sit;
import com.zc.mapper.SitMapper;
import com.zc.service.ISitService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author wz
 * @since 2023-03-31
 */
@Service
public class SitService extends ServiceImpl<SitMapper, Sit> implements ISitService {

}
