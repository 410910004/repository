package com.zc.controller;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zc.common.QueryPageParam;
import com.zc.common.Result;
import com.zc.entity.FaceInfo;
import com.zc.service.impl.FaceInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author wz
 * @since 2023-03-26
 */
@RestController
@RequestMapping("/faceInfo")
public class FaceInfoController {

    @Autowired
    private FaceInfoService faceInfoService;


    //分页查询
    @PostMapping("/listPage")
    public Result listPage(@RequestBody QueryPageParam query) {
        Page<FaceInfo> page = new Page<>();
        //当前页
        page.setCurrent(query.getPageNum());
        //一页多少条
        page.setSize(query.getPageSize());
        IPage result = faceInfoService.page(page);
        return Result.suc(result.getTotal(), result.getRecords());
    }
}
