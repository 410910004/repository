package com.zc.controller;


import com.zc.common.Result;
import com.zc.entity.Info;
import com.zc.service.impl.InfoService;
import com.zc.service.impl.SitService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author wz
 * @since 2023-04-05
 */
@RestController
@RequestMapping("/info")
public class InfoController {
    @Autowired
    private InfoService infoService;
    //登录
    @PostMapping("/login")
    public Result login(@RequestBody Info info) {   //@RequestBody用于接收前端的参数
        List list = infoService.lambdaQuery()
                .eq(Info::getUsername, info.getUsername())
                .eq(Info::getPassword, info.getPassword())
                .list();
        return list.size() > 0 ? Result.suc(list.get(0)) : Result.fail();
    }
}
