package com.zc.service.impl;

import com.zc.entity.FaceInfo;
import com.zc.mapper.FaceInfoMapper;
import com.zc.service.IFaceInfoService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author wz
 * @since 2023-03-26
 */
@Service
public class FaceInfoService extends ServiceImpl<FaceInfoMapper, FaceInfo> implements IFaceInfoService {

}
