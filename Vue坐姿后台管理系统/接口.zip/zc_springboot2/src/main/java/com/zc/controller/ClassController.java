package com.zc.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author wz
 * @since 2023-03-26
 */
@RestController
@RequestMapping("/class")
public class ClassController {

}
