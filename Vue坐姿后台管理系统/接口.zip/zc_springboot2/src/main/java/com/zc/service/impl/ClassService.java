package com.zc.service.impl;

import com.zc.entity.Class;
import com.zc.mapper.ClassMapper;
import com.zc.service.IClassService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author wz
 * @since 2023-03-26
 */
@Service
public class ClassService extends ServiceImpl<ClassMapper, Class> implements IClassService {

}
