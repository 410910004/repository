package com.zc.entity;

import java.time.LocalDateTime;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 
 * </p>
 *
 * @author wz
 * @since 2023-03-26
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value="Attendance对象", description="")
public class Attendance implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer id;

    @ApiModelProperty(value = "学生学号")
    private Integer no;

    @ApiModelProperty(value = "学生姓名")
    private String name;

    @ApiModelProperty(value = "学生性别")
    private String sex;

    @ApiModelProperty(value = "签到信息")
    private String msg;

    @ApiModelProperty(value = "签到时间")
    private LocalDateTime time;


}
