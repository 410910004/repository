package com.zc.controller;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zc.common.QueryPageParam;
import com.zc.common.Result;
import com.zc.entity.Attendance;
import com.zc.entity.FaceInfo;
import com.zc.entity.Student;
import com.zc.service.impl.FaceInfoService;
import com.zc.service.impl.StudentService;
import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author wz
 * @since 2023-03-26
 */
@RestController
@RequestMapping("/student")
public class StudentController {
    @Autowired
    private StudentService studentService;


    //分页查询
    @PostMapping("/listPage")
    public Result listPage(@RequestBody QueryPageParam query) {
        Page<Student> page = new Page<>();
        //当前页
        page.setCurrent(query.getPageNum());
        //一页多少条
        page.setSize(query.getPageSize());
        IPage result = studentService.page(page);
        return Result.suc(result.getTotal(), result.getRecords());
    }

    private String imgId=null;      //id
    @PostMapping("/setId")
    public Result setId(@RequestParam String id){
        imgId=id.trim();
        if (imgId == null || imgId==""){
            return Result.fail();
        }
        return Result.suc();
    }

    //上传文件的本地路径
    @Value("${fileData.uploadRealPath}")
    private String uploadRealPath;

    //上传图片
    @PostMapping("/uploadPictures")
    public Result uploadPictures(@RequestParam("file") MultipartFile file){
        //获取当前虚拟图片路径
        List<Student> list = studentService.lambdaQuery().eq(Student::getId, imgId).list();
        String img = list.get(0).getImg();
        String studentid=list.get(0).getId()+"";
        //删除原来图片
        File oldFile=new File(uploadRealPath+img);
        oldFile.delete();
        //获取原始名称
        String fileName=file.getOriginalFilename();

        //获取后缀名
        assert fileName != null;
        //String suffixName=fileName.substring(fileName.lastIndexOf("."));
        //文件重命名,防止重复
        UUID uuid=UUID.randomUUID();
        //文件本地保存路径  在学生id的文件夹里面
        String localFilePath=uploadRealPath+"student/"+studentid+"/"+ uuid+fileName;
        //文件虚拟保存路径  在学生id的文件夹里面
        String filePath="student/"+studentid+"/"+ uuid+fileName;

        //文件对象
        File dest=new File(localFilePath);
        //判断路径是否存在,如果不存在则创建
        if (!dest.getParentFile().exists()){
            dest.getParentFile().mkdirs();
        }
        try {
            //保存到服务器中
            file.transferTo(dest);
            //修改数据库的虚拟图片路径
            list.get(0).setImg(filePath);
//            list.get(0).setBase(Base64.encodeBase64String(fileToByte(dest)));
            studentService.updateById(list.get(0));
            return Result.suc(list.get(0));
        } catch (IOException e) {
            return Result.fail();
        }

    }

    /**
     * 文件File类型转byte[]
     *
     * @param file
     * @return
     */
    private static byte[] fileToByte(File file) {
        byte[] fileBytes = null;
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(file);
            fileBytes = new byte[(int) file.length()];
            fis.read(fileBytes);
            fis.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return fileBytes;
    }

        //删除
    @GetMapping("/del")
    public Result delete(@RequestParam String id) throws IOException {
        //判断有无文件
        List<Student> list = studentService.lambdaQuery().eq(Student::getId, id).list();
        String img = list.get(0).getImg();
        if (!(img ==null)){
            //删除图片文件
            Path path = Paths.get(uploadRealPath+"\\student\\"+id);
            System.out.println(path);
            Files.walkFileTree(path, new SimpleFileVisitor<Path>() {
                        // 先去遍历删除文件
                        @Override
                        public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                            Files.delete(file);
                            System.out.printf("文件被删除 : %s%n", file);
                            return FileVisitResult.CONTINUE;
                        }
                        // 再去遍历删除目录
                        @Override
                        public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
                            Files.delete(dir);
                            System.out.printf("文件夹被删除: %s%n", dir);
                            return FileVisitResult.CONTINUE;
                        }
                    }
            );
        }
        return studentService.removeById(id)?Result.suc():Result.fail();
    }

    //增加
    @PostMapping("/save")
    public Result save(@RequestBody Student student){   //@RequestBody用于接收前端的参数
        if(studentService.save(student)){
            List list=studentService.lambdaQuery()
                    .eq(Student::getNo,student.getNo())
                    .list();
            return Result.suc(list.get(0));
        }else {
            return Result.fail();
        }
    }

    //修改
    @PostMapping("/mod")
    public Result mod(@RequestBody Student user){   //@RequestBody用于接收前端的参数
        if(studentService.updateById(user)){
            List list = studentService.lambdaQuery().eq(Student::getId, user.getId()).list();
            return Result.suc(list.get(0));
        }else {
            return Result.fail();
        }
    }

    //分页+名称查询
    @PostMapping("/listLike")
    public Result listLike(@RequestBody QueryPageParam query){
        LambdaQueryWrapper<Student> lambdaQueryWrapper=new LambdaQueryWrapper<>();
        HashMap param= query.getParam();
        String name=(String) param.get("name");


        //当参数为空白或者null时,isNotBlank返回false
        if (StringUtils.isNotBlank(name)){
            lambdaQueryWrapper.like(Student::getName,name);
        }

        Page<Student> page=new Page<>();
        //当前页
        page.setCurrent(query.getPageNum());
        //一页多少条
        page.setSize(query.getPageSize());
        IPage result = studentService.page(page, lambdaQueryWrapper);
        return Result.suc(result.getTotal(),result.getRecords());
    }


    //通过id查找姓名
    @GetMapping("/getName")
    public Result getName(@RequestParam String id){        //@RequestParam把请求中的指定名称的参数传递给控制器中的形参赋值
        if(id.isEmpty()) return Result.fail();
        List list = studentService.lambdaQuery().eq(Student::getId, id).list();
        Student student=(Student)list.get(0);
        return list.size()>0?Result.suc(student.getName()):Result.fail();
    }

}
