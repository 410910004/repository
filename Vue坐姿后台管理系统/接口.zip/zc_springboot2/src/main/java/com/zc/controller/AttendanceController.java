package com.zc.controller;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zc.common.QueryPageParam;
import com.zc.common.Result;
import com.zc.entity.Attendance;
import com.zc.entity.FaceInfo;
import com.zc.service.impl.AttendanceService;
import com.zc.service.impl.FaceInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author wz
 * @since 2023-03-26
 */
@RestController
@RequestMapping("/attendance")
public class AttendanceController {
    @Autowired
    private AttendanceService attendanceService;


    //分页查询
    @PostMapping("/listPage")
    public Result listPage(@RequestBody QueryPageParam query) {
        Page<Attendance> page = new Page<>();
        //当前页
        page.setCurrent(query.getPageNum());
        //一页多少条
        page.setSize(query.getPageSize());
        IPage result = attendanceService.page(page);
        return Result.suc(result.getTotal(), result.getRecords());
    }


}
