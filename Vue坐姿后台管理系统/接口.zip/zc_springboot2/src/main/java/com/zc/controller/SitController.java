package com.zc.controller;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zc.common.QueryPageParam;
import com.zc.common.Result;
import com.zc.entity.Sit;
import com.zc.entity.Student;
import com.zc.service.impl.SitService;
import com.zc.service.impl.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author wz
 * @since 2023-03-31
 */
@RestController
@RequestMapping("/sit")
public class SitController {
    @Autowired
    private SitService sitService;

    @Autowired
    private StudentService studentService;

    //分页查询
    @PostMapping("/listPage")
    public Result listPage(@RequestBody QueryPageParam query) {
        Page<Sit> page = new Page<>();
        //当前页
        page.setCurrent(query.getPageNum());
        //一页多少条
        page.setSize(query.getPageSize());
        IPage result = sitService.page(page);
        return Result.suc(result.getTotal(), result.getRecords());
    }


    private String imgId=null;      //id
    @PostMapping("/setId")
    public Result setId(@RequestParam String id){
        imgId=id.trim();
        if (imgId == null || imgId==""){
            return Result.fail();
        }
        return Result.suc();
    }

    //上传文件的本地路径
    @Value("${fileData.uploadRealPath}")
    private String uploadRealPath;

    //上传图片
    @PostMapping("/uploadPictures")
    public Result uploadPictures(@RequestParam("file") MultipartFile file){
        //获取当前虚拟图片路径
        List<Sit> list = sitService.lambdaQuery().eq(Sit::getId, imgId).list();
        String img = list.get(0).getImg();
        String sitId=list.get(0).getId()+"";
        //删除原来图片
        File oldFile=new File(uploadRealPath+img);
        oldFile.delete();
        //获取原始名称
        String fileName=file.getOriginalFilename();

        //获取后缀名
        assert fileName != null;
        //String suffixName=fileName.substring(fileName.lastIndexOf("."));
        //文件重命名,防止重复
        UUID uuid=UUID.randomUUID();
        //文件本地保存路径  在学生id的文件夹里面
        String localFilePath=uploadRealPath+"sit/"+sitId+"/"+ uuid+fileName;
        //文件虚拟保存路径  在学生id的文件夹里面
        String filePath="sit/"+sitId+"/"+ uuid+fileName;

        //文件对象
        File dest=new File(localFilePath);
        //判断路径是否存在,如果不存在则创建
        if (!dest.getParentFile().exists()){
            dest.getParentFile().mkdirs();
        }
        try {
            //保存到服务器中
            file.transferTo(dest);
            //修改数据库的虚拟图片路径
            list.get(0).setImg(filePath);
//            list.get(0).setBase(Base64.encodeBase64String(fileToByte(dest)));
            sitService.updateById(list.get(0));
            return Result.suc(list.get(0));
        } catch (IOException e) {
            return Result.fail();
        }

    }

    /**
     * 文件File类型转byte[]
     *
     * @param file
     * @return
     */
    private static byte[] fileToByte(File file) {
        byte[] fileBytes = null;
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(file);
            fileBytes = new byte[(int) file.length()];
            fis.read(fileBytes);
            fis.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return fileBytes;
    }

    //删除
    @GetMapping("/del")
    public Result delete(@RequestParam String id) throws IOException {
        //判断有无文件
        List<Sit> list = sitService.lambdaQuery().eq(Sit::getId, id).list();
        String img = list.get(0).getImg();
        if (!(img ==null)){
            //删除图片文件
            Path path = Paths.get(uploadRealPath+"\\sit\\"+id);
            System.out.println(path);
            Files.walkFileTree(path, new SimpleFileVisitor<Path>() {
                        // 先去遍历删除文件
                        @Override
                        public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                            Files.delete(file);
                            System.out.printf("文件被删除 : %s%n", file);
                            return FileVisitResult.CONTINUE;
                        }
                        // 再去遍历删除目录
                        @Override
                        public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
                            Files.delete(dir);
                            System.out.printf("文件夹被删除: %s%n", dir);
                            return FileVisitResult.CONTINUE;
                        }
                    }
            );
        }
        return sitService.removeById(id)?Result.suc():Result.fail();
    }

    //统计分数
    @GetMapping("/statisticalScore")
    public Result statisticalScore(@RequestParam String stuid){        //@RequestParam把请求中的指定名称的参数传递给控制器中的形参赋值
        //获取当前时间
        LocalDate localDate = LocalDate.now();
        //设置查询几月前
        //减少6个月
        //localDate = localDate.minusMonths(6);
        //减少1天
        localDate = localDate.minusDays(1);
        List list = sitService.lambdaQuery()
                .eq(Sit::getStuid, stuid)
                .list();
        double num=0.0;
        int length=0;
        for (Object obj:list) {
            Sit sit=(Sit)obj;
            String Time=sit.getUpdatetime().toString();
            LocalDate date = LocalDate.of(Integer.parseInt(Time.substring(0,4)),Integer.parseInt(Time.substring(5,7)),Integer.parseInt(Time.substring(8,10)));
            //如果两个日期相等，则返回值为0。
            //如果localDate在date参数之后，则返回值大于0。
            //如果localDate在date参数之前，则返回值小于0。
            //在localDate在date参数之前或相等，判断成功
            if (localDate.compareTo(date)<=0){
                if (sit.getStart()!=null){
                    length++;
                    num+=sit.getStart();
                }
            }
        }
        if (list.size()>0){
            if (length==0){
                return Result.fail();
            }else {
                //%.1f表示保留后一位，能四舍五入
                return Result.suc(String.format("%.1f",num/length));
            }
        }else {
            return Result.fail();
        }
    }

    //分页+名称查询
    @PostMapping("/listLike")
    public Result listLike(@RequestBody QueryPageParam query){
        LambdaQueryWrapper<Sit> lambdaQueryWrapper=new LambdaQueryWrapper<>();
        HashMap param= query.getParam();
        String name=(String) param.get("name");



        //当参数为空白或者null时,isNotBlank返回false
        if (StringUtils.isNotBlank(name)){
            List list=studentService.lambdaQuery().like(Student::getName, name).list();
            String arr="";
            for (Object obj:list) {
                Student student=(Student)obj;
                arr=arr+student.getId()+",";
            }

            arr=arr.substring(0,arr.length()-1);

            List<String> typeList = new ArrayList<>();
            if(arr != null) {
                String[] typeStr = arr .split(",");
                for (int i = 0; i < typeStr.length; i++) {
                    typeList.add(typeStr[i]);
                }
            }
            lambdaQueryWrapper.in(Sit::getStuid,typeList);
        }

        Page<Sit> page=new Page<>();
        //当前页
        page.setCurrent(query.getPageNum());
        //一页多少条
        page.setSize(query.getPageSize());
        IPage result = sitService.page(page, lambdaQueryWrapper);
        return Result.suc(result.getTotal(),result.getRecords());
    }


}
