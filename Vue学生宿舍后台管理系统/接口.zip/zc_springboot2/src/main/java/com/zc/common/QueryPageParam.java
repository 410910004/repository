package com.zc.common;

import lombok.Data;

import java.util.HashMap;

/**
 * 分页的封装类
 */

@Data       //设置set get
public class QueryPageParam {
    private static int PAGE_SIZE=20;
    private static int PAGE_NUM=1;

    private int pageSize=PAGE_SIZE;
    private int pageNum=PAGE_NUM;
    //其他的参数
    private HashMap param=new HashMap();
}
