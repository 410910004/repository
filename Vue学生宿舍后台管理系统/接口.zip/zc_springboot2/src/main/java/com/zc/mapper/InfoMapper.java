package com.zc.mapper;

import com.zc.entity.Info;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author wz
 * @since 2023-04-29
 */
public interface InfoMapper extends BaseMapper<Info> {

}
