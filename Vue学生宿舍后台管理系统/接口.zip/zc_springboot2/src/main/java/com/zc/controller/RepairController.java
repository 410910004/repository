package com.zc.controller;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zc.common.QueryPageParam;
import com.zc.common.Result;
import com.zc.entity.Repair;
import com.zc.service.impl.RepairService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author wz
 * @since 2023-04-29
 */
@RestController
@RequestMapping("/repair")
public class RepairController {
    @Autowired
    private RepairService repairService;


    //分页查询
    @PostMapping("/listPage")
    public Result listPage(@RequestBody QueryPageParam query) {
        Page<Repair> page = new Page<>();
        //当前页
        page.setCurrent(query.getPageNum());
        //一页多少条
        page.setSize(query.getPageSize());
        IPage result = repairService.page(page);
        return Result.suc(result.getTotal(), result.getRecords());
    }

    //删除
    @GetMapping("/del")
    public Result delete(@RequestParam String id)  {

        return repairService.removeById(id)?Result.suc():Result.fail();
    }

    //增加
    @PostMapping("/save")
    public Result save(@RequestBody Repair repair){   //@RequestBody用于接收前端的参数
        if(repairService.save(repair)){
            List list=repairService.lambdaQuery()
                    .eq(Repair::getId,repair.getId())
                    .list();
            return Result.suc(list.get(0));
        }else {
            return Result.fail();
        }
    }

    //修改
    @PostMapping("/mod")
    public Result mod(@RequestBody Repair repair){   //@RequestBody用于接收前端的参数
        if(repairService.updateById(repair)){
            List list = repairService.lambdaQuery().eq(Repair::getId, repair.getId()).list();
            return Result.suc(list.get(0));
        }else {
            return Result.fail();
        }
    }

    //分页+名称查询
    @PostMapping("/listLike")
    public Result listLike(@RequestBody QueryPageParam query){
        LambdaQueryWrapper<Repair> lambdaQueryWrapper=new LambdaQueryWrapper<>();
        HashMap param= query.getParam();
        String name=(String) param.get("name");


        //当参数为空白或者null时,isNotBlank返回false
        if (StringUtils.isNotBlank(name)){
            lambdaQueryWrapper.like(Repair::getSname,name);
        }

        Page<Repair> page=new Page<>();
        //当前页
        page.setCurrent(query.getPageNum());
        //一页多少条
        page.setSize(query.getPageSize());
        IPage result = repairService.page(page, lambdaQueryWrapper);
        return Result.suc(result.getTotal(),result.getRecords());
    }
}
