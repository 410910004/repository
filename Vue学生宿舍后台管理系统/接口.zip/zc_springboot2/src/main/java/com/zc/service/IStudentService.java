package com.zc.service;

import com.zc.entity.Student;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author wz
 * @since 2023-04-29
 */
public interface IStudentService extends IService<Student> {

}
