package com.zc.controller;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zc.common.QueryPageParam;
import com.zc.common.Result;
import com.zc.entity.Class;
import com.zc.entity.Dormitory;
import com.zc.service.impl.DormitoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author wz
 * @since 2023-04-29
 */
@RestController
@RequestMapping("/dormitory")
public class DormitoryController {
    @Autowired
    private DormitoryService dormitoryService;


    //分页查询
    @PostMapping("/listPage")
    public Result listPage(@RequestBody QueryPageParam query) {
        Page<Dormitory> page = new Page<>();
        //当前页
        page.setCurrent(query.getPageNum());
        //一页多少条
        page.setSize(query.getPageSize());
        IPage result = dormitoryService.page(page);
        return Result.suc(result.getTotal(), result.getRecords());
    }

    //分页+名称查询
    @PostMapping("/listLike")
    public Result listLike(@RequestBody QueryPageParam query){
        LambdaQueryWrapper<Dormitory> lambdaQueryWrapper=new LambdaQueryWrapper<>();
        HashMap param= query.getParam();
        String name=(String) param.get("name");


        //当参数为空白或者null时,isNotBlank返回false
        if (StringUtils.isNotBlank(name)){
            lambdaQueryWrapper.like(Dormitory::getDname,name);
        }

        Page<Dormitory> page=new Page<>();
        //当前页
        page.setCurrent(query.getPageNum());
        //一页多少条
        page.setSize(query.getPageSize());
        IPage result = dormitoryService.page(page, lambdaQueryWrapper);
        return Result.suc(result.getTotal(),result.getRecords());
    }

    //增加
    @PostMapping("/save")
    public Result save(@RequestBody Dormitory dormitory){   //@RequestBody用于接收前端的参数
        if(dormitoryService.save(dormitory)){
            List list=dormitoryService.lambdaQuery()
                    .eq(Dormitory::getDname,dormitory.getDname())
                    .list();
            System.out.println(dormitory.getDname());
            return Result.suc(list.get(0));
        }else {
            return Result.fail();
        }
    }
    //修改
    @PostMapping("/mod")
    public Result mod(@RequestBody Dormitory dormitory){   //@RequestBody用于接收前端的参数
        if(dormitoryService.updateById(dormitory)){
            List list = dormitoryService.lambdaQuery().eq(Dormitory::getId, dormitory.getId()).list();
            return Result.suc(list.get(0));
        }else {
            return Result.fail();
        }
    }

    //删除
    @GetMapping("/del")
    public Result delete(@RequestParam String id) {
        //判断有无文件

        return dormitoryService.removeById(id)?Result.suc():Result.fail();
    }
}
