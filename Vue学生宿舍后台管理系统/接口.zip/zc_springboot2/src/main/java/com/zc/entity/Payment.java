package com.zc.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 
 * </p>
 *
 * @author wz
 * @since 2023-04-29
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value="Payment对象", description="")
public class Payment implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "学生id")
    private Integer sid;

    @ApiModelProperty(value = "学生姓名")
    private String sname;

    @ApiModelProperty(value = "宿舍号")
    private String dormitory;

    @ApiModelProperty(value = "宿舍人数")
    private Integer num;

    @ApiModelProperty(value = "开始时间")
    @TableField("startTime")
    private LocalDateTime starttime;

    @ApiModelProperty(value = "结束时间")
    @TableField("endTime")
    private LocalDateTime endtime;

    @ApiModelProperty(value = "费用")
    private String fees;


}
