package com.zc.service;

import com.zc.entity.Dormitory;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author wz
 * @since 2023-04-29
 */
public interface IDormitoryService extends IService<Dormitory> {

}
