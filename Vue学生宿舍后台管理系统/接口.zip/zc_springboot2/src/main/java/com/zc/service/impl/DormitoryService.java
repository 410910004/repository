package com.zc.service.impl;

import com.zc.entity.Dormitory;
import com.zc.mapper.DormitoryMapper;
import com.zc.service.IDormitoryService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author wz
 * @since 2023-04-29
 */
@Service
public class DormitoryService extends ServiceImpl<DormitoryMapper, Dormitory> implements IDormitoryService {

}
