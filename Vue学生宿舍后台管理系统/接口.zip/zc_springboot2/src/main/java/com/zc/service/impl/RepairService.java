package com.zc.service.impl;

import com.zc.entity.Repair;
import com.zc.mapper.RepairMapper;
import com.zc.service.IRepairService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author wz
 * @since 2023-04-29
 */
@Service
public class RepairService extends ServiceImpl<RepairMapper, Repair> implements IRepairService {

}
