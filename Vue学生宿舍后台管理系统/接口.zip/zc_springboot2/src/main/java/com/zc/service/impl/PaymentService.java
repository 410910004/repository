package com.zc.service.impl;

import com.zc.entity.Payment;
import com.zc.mapper.PaymentMapper;
import com.zc.service.IPaymentService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author wz
 * @since 2023-04-29
 */
@Service
public class PaymentService extends ServiceImpl<PaymentMapper, Payment> implements IPaymentService {

}
