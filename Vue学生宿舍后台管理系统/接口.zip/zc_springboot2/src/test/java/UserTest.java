//import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
//import com.baomidou.mybatisplus.core.metadata.IPage;
//import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
//import com.zc.ZCApplication;
//import com.zc.entity.User;
//import com.zc.mapper.UserMapper;
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//
//import java.util.List;
//
//@SpringBootTest(classes = ZCApplication.class)
//public class UserTest {
//    @Autowired
//    UserMapper userMapper;
//
//    @Test
//    public void test01(){
//        System.out.println("---查询所有的用户---");
//        List<User> list=userMapper.selectList(null);
//        for (User u:list
//             ) {
//            System.out.println(u.getId()+"\t"+u.getName()+"\t"+u.getEmail());
//        }
//    }
//
//    @Test
//    public void test02(){
//        System.out.println("---添加用户---");
//        User user=new User(null,"wangzheng779",23,"1374739811@qq.com");
//        userMapper.insert(user);
//    }
//
//    @Test
//    public void test03(){
//        QueryWrapper queryWrapper=new QueryWrapper();
//        queryWrapper.eq("age",23);
//        queryWrapper.likeRight("name","wangzheng779");
//        List<User> list=userMapper.selectList(queryWrapper);
//        for (User u:list
//        ) {
//            System.out.println(u.getId()+"\t"+u.getName()+"\t"+u.getEmail());
//        }
//    }
//
//    @Test
//    public void test04(){
//        User user=new User();
//        user.setId(2L);
//        user.setAge(23);
//        int i=userMapper.updateById(user);
//        if (i <0) {
//            System.out.println("修改错误");
//        }else {
//            System.out.println("修改成功");
//        }
//    }
//
//    @Test
//    public void test05(){
//        Page<User> page=new Page<>(1,2);
//        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
//        queryWrapper.like("name","T");
//        IPage<User> userIPage=userMapper.selectPage(page,queryWrapper);
//        System.out.println("总记录数:"+userIPage.getTotal());
//        System.out.println("总页数:"+userIPage.getPages());
//        List<User> userList=userIPage.getRecords();
//        userList.forEach(System.out::println);
//    }
//
//}
