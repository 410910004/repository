<template>
  <div>
    添加|修改Sku
  </div>
</template>

<script>
export default {
    name:'SkuEdit'
}
</script>

<style>

</style>